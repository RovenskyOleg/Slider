# Slider App
Native JS and CSS

install package: npm install

start server use command: node server.js