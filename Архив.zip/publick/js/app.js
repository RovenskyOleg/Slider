// "use strict";

function BaseSlider() {
    this.init = function (config) {
        this.config = config;
        this.imgNum = 0;
        //this.imgLength = this.config.images.length - 1;

        if (this.mode[this.config.mode]) {
            this.mode[this.config.mode](this.config)
        } else {
            console.log('error');
        }
    }

    this.changeSlide = function (val) {
        //imgNum = imgNum + direction;
        console.log( val );
        console.log( this.config );
        
        // if (imgNum > imgLength) {
        //     imgNum = 0;
        // }
        
        // if (imgNum < 0) {
        //     imgNum = imgLength;
        //}

      //  document.getElementById('slideshow').src = images[imgNum];
        
       // return false;
    }

    this.mode = {
        auto: function (config) {
           // var swipeDelay = config.swipeDelay || 1000;
            console.log( this.c )
            // setInterval(function() {
            //     // this.changeSlide(1);
            // }, swipeDelay);
        },
        manual: function (config) {
            console.log('modeManual');
        },
        automanual: function (config) {
            console.log('modeAutomanual');
        }
    }

    this.render = function () {
        console.log(this.config)
    }

    return this;
}

function Slider() {
    this.render = function () {
        console.log(this.config)
    }

    return this;
}

Slider.prototype = new BaseSlider();

function FadeIn() {
    this.render = function () {
        console.log(this.config)
    }

    return this;
}

FadeIn.prototype = new BaseSlider();

window.onload = function() {
    var config = {
        images: [
            '../publick/img/1.png',
            '../publick/img/2.png',
            '../publick/img/3.png',
            '../publick/img/4.png'
        ],
        mode: 'auto',
        swipeSpeed: 500,
        swipeDelay: 3000
    },
        configManual = {
            images: [
                '../publick/img/1.png',
                '../publick/img/2.png',
                '../publick/img/3.png',
                '../publick/img/4.png'
            ],
            mode: 'manual',
            swipeSpeed: 500,
            swipeDelay: 3000
        };

    var slider_type = {
        baseSlider: new BaseSlider(),
        slider: new Slider(),
        fadein: new FadeIn()
    };

    slider_type.baseSlider.init(config);
   // slider_type.slider.init(configManual);
    // slider_type.baseSlider.render();
    
 }
