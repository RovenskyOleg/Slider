mockJSON = {
    "ads": [
        {
            "data": {
                "ad_hides": {
                    "enabled": true,
                    "value": 25
                },
                "click_url": "http://loopme.me/go2/DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M",
                "type": "IMAGE",
                "image_url": "http://i.loopme.me/59815bf617b6446f.png",
                "share_url": "http://loopme.me/go2/DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M",
                "ad_shares": {
                    "enabled": true,
                    "value": 17
                },
                "ad_likes": {
                    "enabled": true,
                    "value": 27
                },
                "id": "DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M",
                "download_btn_color": "#00AF33",
                "delay": 0
            },
            "beacons": {
                "ad_show": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=AD_SHOW",
                "ad_like": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=AD_LIKE",
                "ad_hide": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=AD_HIDE",
                "ad_share": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=AD_SHARE",
                "video_start": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=VIDEO_STARTS",
                "video_time": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=VIDEO_TIMES",
                "video_complete": "http://loopme.me/api/v2/events?id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M&et=VIDEO_COMPLETES"
            }
        }
    ],
    "version": "v0.2.421",
    "session": {
        "si": "61eb93hd",
        "beacons": {
            "inbox_open": "http://loopme.me/api/v2/events?et=INBOX_OPEN&rid=61eb93hd&id=DFoDYjOn6qGR7NPH_3Gu3aXtXFXV_57Luk5xlds6O1M",
            "ad_close": "http://loopme.me/api/v2/events?et=AD_CLOSE&rid=61eb93hd"
        }
    }
};